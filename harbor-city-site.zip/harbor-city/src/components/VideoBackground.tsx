import { useEffect, useRef } from 'react'
import type { Media } from '../data/slides'

/** Full-bleed media layers. The active layer fades in; the video restarts when its slide becomes active.
 *  If the video cannot play, its poster stays visible. */
export default function VideoBackground({ media, active }: { media: Media[]; active: number }) {
  const vref = useRef<HTMLVideoElement>(null)
  useEffect(() => {
    const v = vref.current
    if (!v) return
    if (media[active].type === 'video') { v.currentTime = 0; v.play().catch(() => undefined) } else v.pause()
  }, [active, media])
  return (
    <div className="m" aria-hidden="true">
      {media.map((m, n) => m.type === 'video'
        ? <video key={n} ref={vref} className={n === active ? 'on' : ''} src={m.src} poster={m.poster} muted playsInline preload="auto" />
        : <img key={n} className={n === active ? 'on' : ''} src={m.src} alt="" decoding="async" style={{ objectPosition: m.pos }} />)}
    </div>
  )
}
