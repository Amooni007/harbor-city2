import { Link } from 'react-router-dom'
import { crane } from '../data/media'

interface Props { title?: string; text?: string; button?: string; to?: string }
export default function CtaBand({ title = 'Let’s Build Something Exceptional Together.', text = 'Connect with our team to discuss your marine, engineering and supply requirements.', button = 'Contact Harbor City', to = '/contact' }: Props) {
  return (
    <section className="band" style={{ backgroundImage: `linear-gradient(rgba(26,47,89,.8),rgba(26,47,89,.93)),url(${crane})`, backgroundSize: 'cover', backgroundPosition: 'center' }}>
      <h2 data-r>{title}</h2>
      <p data-r>{text}</p>
      <Link className="btn fill" to={to}>{button}</Link>
    </section>
  )
}
