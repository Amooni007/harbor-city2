import { useEffect, useRef, useState } from 'react'
import { Routes, useLocation, type RouteProps } from 'react-router-dom'
import { gsap } from 'gsap'
import PageLoader from './PageLoader'
import { reduced } from '../hooks/useReveal'
import { scrollToTop } from '../hooks/useSmoothScroll'

/** Renders routes; on navigation the tower overlay covers the screen, the page swaps, then the overlay lifts (~1.2s). */
export default function PageTransition({ children }: { children: RouteProps['children'] }) {
  const location = useLocation()
  const [shown, setShown] = useState(location)
  const ld = useRef<HTMLDivElement>(null)
  const booted = useRef(false)

  useEffect(() => {
    const el = ld.current
    if (!el || reduced()) { setShown(location); return }
    const tr = el.querySelector('.tr'), b = el.querySelector('b')
    const first = !booted.current
    booted.current = true
    const tl = gsap.timeline()
    tl.set(el, { visibility: 'visible', y: first ? '0%' : '100%' })
    if (!first) tl.to(el, { y: '0%', duration: 0.4, ease: 'power3.inOut' })
    tl.fromTo(tr, { clipPath: 'inset(100% 0 0 0)' }, { clipPath: 'inset(0% 0 0 0)', duration: 0.45, ease: 'power2.out' }, first ? 0 : '-=.1')
      .fromTo(b, { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.3 }, '<.15')
      .add(() => { setShown(location); scrollToTop() })
      .to(el, { y: '-100%', duration: 0.5, ease: 'power3.inOut' }, '+=.1')
      .set(el, { visibility: 'hidden' })
    return () => { tl.kill() }
  }, [location.pathname]) // eslint-disable-line react-hooks/exhaustive-deps

  return (<><PageLoader ref={ld} /><Routes location={shown}>{children}</Routes></>)
}
