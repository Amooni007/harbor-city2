import { PHOTOS } from '../data/media'

/** A supplied photograph if one is mapped to this label, otherwise a clearly marked photo slot. */
export default function Photo({ label, className = '' }: { label: string; className?: string }) {
  const p = PHOTOS[label]
  if (p) return <figure className={`ph ${className}`} style={p.fit ? { background: '#fff' } : undefined}><img src={p.src} alt={label} loading="lazy" decoding="async" style={{ objectPosition: p.pos, ...(p.fit ? { objectFit: p.fit } : {}) }} /></figure>
  return (
    <figure className={`ph ${className}`} role="img" aria-label={`Image slot: ${label}`}>
      <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true"><g fill="none" stroke="#fff" strokeOpacity=".25"><path d="M0 210q50-24 100 0t100 0 100 0 100 0" /><path d="M0 240q50-24 100 0t100 0 100 0 100 0" /><path d="M60 190V90l40-30h120l40 30v100" /></g></svg>
      <figcaption>Photo slot · {label}</figcaption>
    </figure>
  )
}
