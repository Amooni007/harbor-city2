import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { scrollToTop } from '../hooks/useSmoothScroll'

/** Fallback scroll reset (used when the animated transition is disabled). */
export default function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { scrollToTop() }, [pathname])
  return null
}
