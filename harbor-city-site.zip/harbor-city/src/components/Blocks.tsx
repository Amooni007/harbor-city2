import { Link } from 'react-router-dom'
import Photo from './Photo'
import { SERVICES, CAPABILITIES } from '../data/content'

export const Tags = ({ items }: { items: string[] }) => <ul className="t">{items.map(x => <li key={x}>{x}</li>)}</ul>

export function ServiceRows({ home = false }: { home?: boolean }) {
  return <>{SERVICES.map((s, i) => { const h = home ? s.home : undefined; return (
    <div key={s.title} className={`split ${i % 2 ? 'rev' : ''}`} style={{ marginBottom: 'clamp(48px,7vw,100px)' }}>
      <Photo label={h?.photo ?? s.photo} />
      <div data-r>
        <p className="eyebrow">0{i + 1}{h ? ` – ${h.eyebrow}` : ''}</p>
        <h3 style={{ fontSize: 'clamp(24px,3vw,40px)', fontWeight: 300, marginBottom: 16 }}>{h?.title ?? s.title}</h3>
        <p className="lead" style={{ margin: 0 }}>{h?.text ?? s.text}</p>
        <Tags items={h?.items ?? s.items} />
        <p style={{ marginTop: 28 }}>{h ? <Link className="btn ink" to={h.to}>{h.cta}</Link> : <Link className="btn ink" to={`/contact?service=${encodeURIComponent(s.title)}`}>Enquire about {s.title}</Link>}</p>
      </div>
    </div>) })}</>
}

export function IndustryColumns() {
  const cols: [string, string[]][] = [['Port Services', SERVICES[0].items], ['Supplies', SERVICES[2].items.slice(0, 6)], ['Construction', SERVICES[3].items], ['Environment', SERVICES[4].items]]
  return <div className="cols">{cols.map(([t, l]) => <div key={t} data-r><h3>{t}</h3><ul>{l.map(x => <li key={x}>{x}</li>)}</ul></div>)}</div>
}

export function CapabilityGrid() {
  return <div className="cap">{CAPABILITIES.map((c, i) => <div key={c} data-r><b>{String(i + 1).padStart(2, '0')}</b>{c}</div>)}</div>
}

export function HseSection() {
  return (
    <div className="split">
      <div data-r><p className="eyebrow">HSE policy</p><h2>Health, safety and environmental management come first.</h2>
        <p className="lead" style={{ marginTop: 22 }}>All staff and handlers are thoroughly trained on the methods of ensuring high health and safety standards. The company follows industry best practices and processes to conform to the highest standards of safety and sustainability.</p></div>
      <Photo label="welder in protective equipment" />
    </div>)
}
