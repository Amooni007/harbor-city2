import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import logo from '../assets/logos/harbor-city-logo.png'
import logoLight from '../assets/logos/harbor-city-logo-light.png'
import { NAV, SERVICES } from '../data/content'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const [solid, setSolid] = useState(false)
  const { pathname } = useLocation()
  // pages whose first section is a full-bleed photo: the bar starts transparent over it
  const overlay = pathname === '/' || pathname.startsWith('/services/')
  useEffect(() => { setOpen(false) }, [pathname])
  useEffect(() => {
    // hysteresis (down at 40px, back at 12px) so the bar never flickers around the threshold
    const on = () => setSolid(s => (s ? scrollY > 12 : scrollY > 40))
    on(); addEventListener('scroll', on, { passive: true })
    return () => removeEventListener('scroll', on)
  }, [])
  return (
    <header className={`${overlay ? 'over ' : ''}${solid || open ? 'solid' : ''}`.trim()}>
      <Link className="logo" to="/" aria-label="Harbor City Limited home"><img className="dk" src={logo} alt="Harbor City" width={139} height={46} /><img className="lt" src={logoLight} alt="" aria-hidden="true" width={139} height={46} /></Link>
      <button id="mb" aria-expanded={open} aria-controls="nav" onClick={() => setOpen(o => !o)}>{open ? 'CLOSE' : 'MENU'}</button>
      <nav id="nav" className={open ? 'open' : ''} aria-label="Main">
        {NAV.map(n => n.to === '/services' ? (
          <div className="dd" key={n.to}>
            <NavLink to={n.to} className={({ isActive }) => (isActive ? 'on' : '')}>{n.label}</NavLink>
            <ul>{SERVICES.map(s => <li key={s.title}><Link to="/services">{s.title}</Link></li>)}</ul>
          </div>
        ) : <NavLink key={n.to} to={n.to} end={n.to === '/'} className={({ isActive }) => (isActive ? 'on' : '')}>{n.label}</NavLink>)}
      </nav>
    </header>
  )
}
