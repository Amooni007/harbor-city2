import { useState, type TouchEvent } from 'react'
import { Link } from 'react-router-dom'
import VideoBackground from './VideoBackground'
import { SLIDES } from '../data/slides'

const MEDIA = SLIDES.map(s => s.media)

/** Homepage hero: five slides, each with its own media, headline, description and call to action.
 *  Timing is driven by the active indicator's CSS animation, so text, image and progress cannot drift apart. */
export default function HeroSlideshow() {
  const [i, setI] = useState(0)
  const [hover, setHover] = useState(false)
  const [userPaused, setUserPaused] = useState(false)
  const [start, setStart] = useState<{ x: number; y: number } | null>(null)
  const go = (n: number) => setI((n + SLIDES.length) % SLIDES.length)
  const paused = hover || userPaused

  const onEnd = (e: TouchEvent) => {
    if (!start) return
    const t = e.changedTouches[0], dx = t.clientX - start.x, dy = t.clientY - start.y
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) go(i + (dx < 0 ? 1 : -1))
    setStart(null)
  }

  return (
    <section className={`hero${paused ? ' paused' : ''}`} role="region" aria-roledescription="carousel" aria-label="Harbor City highlights"
      onPointerEnter={e => e.pointerType === 'mouse' && setHover(true)} onPointerLeave={() => setHover(false)}
      onTouchStart={e => setStart({ x: e.touches[0].clientX, y: e.touches[0].clientY })} onTouchEnd={onEnd}>
      <VideoBackground media={MEDIA} active={i} />
      <div className="est" aria-hidden="true">2014</div>
      <h1 className="sr">Harbor City Limited — Engineering Excellence. Delivering Beyond Expectations.</h1>
      <p className="eyebrow" style={{ color: '#ff6b73' }}>Mombasa · Gateway to East Africa</p>
      <div className="sl-stack" aria-live={paused ? 'polite' : 'off'}>
        {SLIDES.map((s, n) => (
          <div key={s.title} className={`sl-text${n === i ? ' on' : ''}`} aria-hidden={n !== i} role="group" aria-roledescription="slide" aria-label={`${n + 1} of ${SLIDES.length}`}>
            <h2 className="sh">{s.title}</h2>
            <p>{s.text}</p>
            <Link className="btn fill" to={s.to}>{s.cta}</Link>
          </div>
        ))}
      </div>
      <div className="sl-nav">
        <div className="dots">
          {SLIDES.map((s, n) => (
            <button key={s.title} className={n === i ? 'on' : ''} onClick={() => go(n)} aria-label={`Go to slide ${n + 1}: ${s.title}`} aria-current={n === i}>
              <i onAnimationEnd={() => n === i && go(i + 1)} />
            </button>
          ))}
        </div>
        <span className="cnt">{String(i + 1).padStart(2, '0')} / {String(SLIDES.length).padStart(2, '0')}</span>
        <div className="arrows">
          <button onClick={() => go(i - 1)} aria-label="Previous slide">‹</button>
          <button onClick={() => setUserPaused(p => !p)} aria-label={userPaused ? 'Play slideshow' : 'Pause slideshow'}>{userPaused ? '▶' : '❚❚'}</button>
          <button onClick={() => go(i + 1)} aria-label="Next slide">›</button>
        </div>
      </div>
    </section>
  )
}
