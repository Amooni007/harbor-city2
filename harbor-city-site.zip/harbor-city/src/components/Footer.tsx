import { Link } from 'react-router-dom'
import logo from '../assets/logos/harbor-city-logo.png'
import { CONTACT } from '../data/content'

export default function Footer() {
  return (
    <footer>
      <div className="g">
        <div>
          <div style={{ background: '#fff', display: 'inline-block', padding: '12px 16px' }}><img src={logo} alt="Harbor City" width={127} height={42} style={{ display: 'block', height: 42, width: 'auto' }} /></div>
          <p style={{ font: '600 13px var(--sans)', color: '#fff', margin: '16px 0 8px' }}>You Dream It, We Build It</p>
          <p style={{ fontSize: 14, maxWidth: '34ch', margin: 0 }}>A multi-disciplined marine and civil, electrical, mechanical engineering and supplies contractor in Mombasa.</p>
        </div>
        <div><h4>Company</h4><Link to="/about">About us</Link><Link to="/industries">Industries</Link><Link to="/projects">Projects</Link><Link to="/contact">Contact</Link></div>
        <div><h4>Services</h4><Link to="/services">Port Services</Link><Link to="/services">Marine Engineering</Link><Link to="/services">Offshore Support</Link><Link to="/products">Products &amp; Equipment</Link></div>
        <div><h4>Contact</h4><p style={{ fontSize: 14, margin: 0 }}>{CONTACT.address.map(l => <span key={l}>{l}<br /></span>)}<a href={`tel:${CONTACT.tel.replace(/\s/g, '')}`}>{CONTACT.tel}</a><a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></p></div>
      </div>
      <div className="c">© {new Date().getFullYear()} Harbor City Limited. All rights reserved.</div>
    </footer>
  )
}
