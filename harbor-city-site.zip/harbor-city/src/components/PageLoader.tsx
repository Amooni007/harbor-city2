import { forwardRef } from 'react'
import tower from '../assets/logos/tower.png'

/** Branded overlay: the tower symbol cropped from the supplied Harbor City logo, above the name. */
const PageLoader = forwardRef<HTMLDivElement>((_, ref) => (
  <div id="ld" ref={ref} aria-hidden="true">
    <div className="tw"><div className="tr"><img src={tower} alt="" /></div><b>HARBOR CITY</b></div>
  </div>
))
export default PageLoader
