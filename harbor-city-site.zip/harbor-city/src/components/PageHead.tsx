export default function PageHead({ eyebrow, title, lead }: { eyebrow: string; title: string; lead: string }) {
  return (<section className="pg"><p className="eyebrow" style={{ color: '#ff6b73' }}>{eyebrow}</p><h1>{title}</h1><p>{lead}</p></section>)
}
