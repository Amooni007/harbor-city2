import crane from '../assets/images/crane-pier.webp'
import weld from '../assets/images/steel-fabrication.webp'
import cables from '../assets/images/network-patch-panels.webp'
import racks from '../assets/images/equipment-racks.webp'
import cableReels from '../assets/images/cable-reels-port.webp'
import drives from '../assets/images/drive-control-cabinet.webp'
import reefer from '../assets/images/reefer-inspection.webp'
import terminal from '../assets/images/port-terminal-aerial.webp'
import drydockVessel from '../assets/images/drydock-vessel.webp'
import diverChain from '../assets/images/diver-chain-buoy.webp'
import diverShackles from '../assets/images/diver-shackles.webp'
import drydockCutting from '../assets/images/drydock-cutting.webp'
import shipyard from '../assets/images/shipyard-drydock.webp'
import pilingRig from '../assets/images/marine-piling-rig.webp'
import mooring from '../assets/images/mooring-operations.webp'
import hullCleaning from '../assets/images/diver-hull-cleaning.webp'
import hallImg from '../assets/images/switchgear-hall.webp'
import panelImg from '../assets/images/panel-breakers.webp'
import drumsImg from '../assets/images/cable-drums-warehouse.webp'
import pumpsImg from '../assets/images/pumps-motors.webp'
import engineImg from '../assets/images/marine-engine-spares.webp'
import reeferImg from '../assets/images/reefer-socket-technician.webp'
import compImg from '../assets/images/electrical-components.webp'
import liftImg from '../assets/images/lift.webp'
import cabroImg from '../assets/images/cabro-paving.webp'
import frameImg from '../assets/images/construction-frame.webp'
import trayImg from '../assets/images/cable-tray-installation.webp'
import electriciansImg from '../assets/images/electricians-cabling-panels.webp'
import fabShopImg from '../assets/images/fabrication-workshop-welders.webp'
import poster from '../assets/images/hero-poster.webp'
import video from '../assets/videos/hero.mp4'

export { crane, weld, cables, racks, poster, video, terminal, drydockVessel, cableReels, frameImg as constructionFrame }
/** Images that exist. Any label not listed here renders a labelled "photo slot". */
export const PHOTOS: Record<string, { src: string; pos: string; fit?: 'contain' }> = {
  'structured cabling and network patch panels': { src: cables, pos: '40% 50%' },
  'marine pier construction with crawler crane': { src: crane, pos: '78% 50%' },
  'equipment racks in a data hall': { src: racks, pos: '50% 50%' },
  'steel fabrication workshop': { src: weld, pos: '35% 50%' },
  'Mombasa port and marine operations': { src: crane, pos: '20% 50%' },
  'cable reels beside a container ship and gantry crane': { src: cableReels, pos: '35% 50%' },
  'industrial cable reels at a container port': { src: cableReels, pos: '30% 50%' },
  'technician inspecting a reefer container': { src: reefer, pos: '50% 50%' },
  'variable-speed drive and control cabinet': { src: drives, pos: '50% 50%' },
  'commercial diver inspecting a mooring chain and buoy': { src: diverChain, pos: '40% 50%' },
  'diver cleaning a ship hull underwater': { src: hullCleaning, pos: '50% 50%' },
  'dock workers handling mooring ropes at a bollard': { src: mooring, pos: '40% 50%' },
  'marine piling rig working beside a quay': { src: pilingRig, pos: '60% 50%' },
  'vessel in a dry dock with scaffolding': { src: shipyard, pos: '40% 50%' },
  'steel cutting beside a vessel in dry dock': { src: drydockCutting, pos: '30% 50%' },
  'diver handling anchor shackles underwater': { src: diverShackles, pos: '60% 50%' },
  'switchgear line-up in an industrial hall': { src: hallImg, pos: '40% 50%' },
  'marine engine with spare parts laid out': { src: engineImg, pos: '50% 50%' },
  'industrial pump and motor assemblies': { src: pumpsImg, pos: '50% 50%' },
  'cable drums in a warehouse': { src: drumsImg, pos: '50% 50%' },
  'electrical distribution panel with circuit breakers': { src: panelImg, pos: '50% 50%' },
  'technician servicing a reefer container power socket': { src: reeferImg, pos: '50% 55%' },
  'circuit breakers, contactors and terminal blocks': { src: compImg, pos: '50% 50%', fit: 'contain' },
  'hydraulic aluminium man lift platform': { src: liftImg, pos: '50% 50%', fit: 'contain' },
  'cable tray installation in an industrial workshop': { src: trayImg, pos: '45% 50%' },
  'electricians working on cable trays and distribution panels': { src: electriciansImg, pos: '50% 50%' },
  'interlocking cabro paving being compacted': { src: cabroImg, pos: '30% 50%' },
  'welders working on structural steel in a fabrication workshop': { src: fabShopImg, pos: '40% 55%' },
  'welder in protective equipment': { src: weld, pos: '30% 50%' },
}
