import { video, poster, weld, cables, racks, crane } from './media'

export type Media = { type: 'video'; src: string; poster: string } | { type: 'image'; src: string; pos: string }
export interface Slide { title: string; text: string; cta: string; to: string; media: Media }

/** Five hero slides. Copy supplied by Harbor City; each slide uses a different supplied media file. */
export const SLIDES: Slide[] = [
  { title: 'Engineering the Future of Marine & Port Operations', text: 'Integrated marine, civil engineering and technical solutions for a connected world.', cta: 'Explore Our Capabilities', to: '/services',
    media: { type: 'video', src: video, poster } },
  { title: 'Built for the Challenges of the Marine Environment', text: 'From civil engineering to fabrication and welding, we support demanding industrial and marine projects.', cta: 'Discover Our Engineering Services', to: '/services',
    media: { type: 'image', src: weld, pos: '30% 50%' } },
  { title: 'Connecting Infrastructure Through Smart Technology', text: 'Intelligent automation, communication, security and network solutions for modern operations.', cta: 'Explore Our Technology Solutions', to: '/products',
    media: { type: 'image', src: cables, pos: '40% 50%' } },
  { title: 'Expertise, People and Precision in Every Project', text: 'Skilled technical support and project management backed by a commitment to quality and safety.', cta: 'Meet Our Capabilities', to: '/about',
    media: { type: 'image', src: racks, pos: '50% 50%' } },
  { title: 'One Partner. Multiple Engineering Solutions.', text: 'Delivering integrated marine, mechanical, electrical, environmental and port services.', cta: 'Talk to Our Team', to: '/contact',
    media: { type: 'image', src: crane, pos: '62% 50%' } },
]
