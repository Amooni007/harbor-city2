import { useEffect } from 'react'
export function usePageMeta(title: string, description: string) {
  useEffect(() => {
    document.title = `${title} — Harbor City Limited`
    document.querySelector('meta[name="description"]')?.setAttribute('content', description)
  }, [title, description])
}
