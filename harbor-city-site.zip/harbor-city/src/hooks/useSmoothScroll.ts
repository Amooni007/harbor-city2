import { useEffect } from 'react'
import Lenis from 'lenis'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { reduced } from './useReveal'

let lenis: Lenis | null = null
export const scrollToTop = () => (lenis ? lenis.scrollTo(0, { immediate: true }) : window.scrollTo(0, 0))

export const scrollToEl = (el: HTMLElement | null) => {
  if (!el) return
  const top = el.getBoundingClientRect().top + window.scrollY - 80
  lenis ? lenis.scrollTo(top) : window.scrollTo({ top, behavior: 'smooth' })
}

export function useSmoothScroll() {
  useEffect(() => {
    if (reduced()) return
    lenis = new Lenis()
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (t: number) => lenis?.raf(t * 1000)
    gsap.ticker.add(tick); gsap.ticker.lagSmoothing(0)
    return () => { gsap.ticker.remove(tick); lenis?.destroy(); lenis = null }
  }, [])
}
