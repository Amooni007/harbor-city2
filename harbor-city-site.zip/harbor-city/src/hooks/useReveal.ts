import { useLayoutEffect, type RefObject } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
gsap.registerPlugin(ScrollTrigger)
export const reduced = () => matchMedia('(prefers-reduced-motion:reduce)').matches

/** Scroll reveals ([data-r]) and image parallax inside a page. Disabled for reduced motion. */
export function useReveal(root: RefObject<HTMLElement>) {
  useLayoutEffect(() => {
    if (reduced() || !root.current) return
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('[data-r]').forEach(el =>
        gsap.from(el, { y: 40, opacity: 0, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 90%' } }))
      gsap.utils.toArray<HTMLElement>('.ph img').forEach(img =>
        gsap.fromTo(img, { yPercent: -5 }, { yPercent: 5, ease: 'none', scrollTrigger: { trigger: img.parentElement, scrub: true } }))
      gsap.utils.toArray<HTMLElement>('.ph.rv').forEach(el =>
        gsap.fromTo(el, { clipPath: 'inset(0 100% 0 0)' }, { clipPath: 'inset(0 0% 0 0)', duration: 1.3, ease: 'power3.inOut', scrollTrigger: { trigger: el, start: 'top 85%' } }))
      gsap.utils.toArray<HTMLElement>('.flow').forEach(f =>
        gsap.from(f.querySelectorAll('b'), { scale: 0.4, opacity: 0, stagger: 0.2, scrollTrigger: { trigger: f, start: 'top 80%' } }))
    }, root)
    const t = setTimeout(() => ScrollTrigger.refresh(), 300)
    return () => { clearTimeout(t); ctx.revert() }
  }, [root])
}
