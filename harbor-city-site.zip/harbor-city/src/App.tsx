import { Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import PageTransition from './components/PageTransition'
import ScrollToTop from './components/ScrollToTop'
import { useSmoothScroll } from './hooks/useSmoothScroll'
import Home from './pages/Home'
import About from './pages/About'
import Services from './pages/Services'
import Industries from './pages/Industries'
import Products from './pages/Products'
import Projects from './pages/Projects'
import Contact from './pages/Contact'
import PortServices from './pages/PortServices'
import MarineEngineering from './pages/MarineEngineering'
import Supplies from './pages/Supplies'
import Construction from './pages/Construction'

export default function App() {
  useSmoothScroll()
  return (
    <>
      <a href="#main" className="skip">Skip to content</a>
      <Navbar />
      <ScrollToTop />
      <main id="main">
        <PageTransition>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/port-services" element={<PortServices />} />
          <Route path="/services/marine-engineering" element={<MarineEngineering />} />
          <Route path="/services/supplies" element={<Supplies />} />
          <Route path="/services/construction" element={<Construction />} />
          <Route path="/industries" element={<Industries />} />
          <Route path="/products" element={<Products />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<Home />} />
        </PageTransition>
      </main>
      <Footer />
    </>
  )
}
