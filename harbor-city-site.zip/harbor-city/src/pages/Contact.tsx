import { useRef, useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router-dom'
import PageHead from '../components/PageHead'
import { SERVICES, CONTACT } from '../data/content'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

type F = { name: string; company: string; email: string; phone: string; service: string; message: string }

export default function Contact() {
  const root = useRef<HTMLDivElement>(null)
  const [q] = useSearchParams()
  usePageMeta('Contact', 'Contact Harbor City Limited, Nkurumah Road, Mombasa. Telephone +254 41 2318 555.')
  useReveal(root)
  const [f, setF] = useState<F>({ name: '', company: '', email: '', phone: '', service: q.get('service') ?? '', message: q.get('topic') ? `Enquiry: ${q.get('topic')}` : '' })
  const [err, setErr] = useState<Partial<Record<keyof F, string>>>({})
  const [sent, setSent] = useState(false)
  const set = (k: keyof F) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value })

  const submit = (e: FormEvent) => {
    e.preventDefault()
    const er: typeof err = {}
    if (!f.name.trim()) er.name = 'Please enter your name.'
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = 'Please enter a valid email address.'
    if (!f.service) er.service = 'Please choose a service.'
    if (!f.message.trim()) er.message = 'Please enter a message.'
    setErr(er)
    if (Object.keys(er).length) return
    // No backend is configured: this opens the visitor's email app. Replace with a real API call (Formspree, EmailJS, own endpoint).
    const body = `Name: ${f.name}\nCompany: ${f.company}\nPhone: ${f.phone}\nService: ${f.service}\n\n${f.message}`
    window.location.href = `mailto:${CONTACT.email}?subject=${encodeURIComponent('Website enquiry: ' + f.service)}&body=${encodeURIComponent(body)}`
    setSent(true)
  }
  const field = (k: keyof F, label: string, props: React.InputHTMLAttributes<HTMLInputElement> = {}, full = false) => (
    <div className={full ? 'f' : ''}><label htmlFor={k}>{label}</label>
      <input id={k} value={f[k]} onChange={set(k)} aria-invalid={!!err[k]} {...props} /><p className="err">{err[k]}</p></div>)

  return (<div ref={root}>
    <PageHead eyebrow="Contact" title="Talk to the Harbor City team." lead="Tell us about your marine, engineering or supply requirement." />
    <section className="wrap"><div className="split" style={{ alignItems: 'start' }}>
      <div><h3>Harbor City Limited</h3>
        <p className="lead">{CONTACT.address.map(l => <span key={l}>{l}<br /></span>)}</p>
        <p className="lead"><a href={`tel:${CONTACT.tel.replace(/\s/g, '')}`}>{CONTACT.tel}</a><br /><a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a><br />{CONTACT.web}</p>
        <p className="note">Map omitted until the exact office location is verified.</p></div>
      <form onSubmit={submit} noValidate>
        {field('name', 'Name *')}{field('company', 'Company')}{field('email', 'Email *', { type: 'email' })}{field('phone', 'Phone', { type: 'tel' })}
        <div className="f"><label htmlFor="service">Service of interest *</label>
          <select id="service" value={f.service} onChange={set('service')} aria-invalid={!!err.service}><option value="">Select…</option>{SERVICES.map(s => <option key={s.title}>{s.title}</option>)}<option>Products &amp; Equipment</option><option>Other</option></select><p className="err">{err.service}</p></div>
        <div className="f"><label htmlFor="message">Message *</label><textarea id="message" rows={5} value={f.message} onChange={set('message')} aria-invalid={!!err.message} /><p className="err">{err.message}</p></div>
        <div className="f"><button className="btn fill" type="submit">Send enquiry</button>
          <p className="note" style={{ marginTop: 18 }}>{sent ? `Your email app should now open with the enquiry ready to send. If nothing opens, email ${CONTACT.email} directly.` : `This form opens your email app with the enquiry pre-filled for ${CONTACT.email}. Direct submission needs a backend or email service (e.g. Formspree, EmailJS or an API route), which is not configured yet.`}</p></div>
      </form></div></section></div>)
}
