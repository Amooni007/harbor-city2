import { useRef } from 'react'
import { Link } from 'react-router-dom'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { drydockVessel } from '../data/media'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'
import { scrollToEl } from '../hooks/useSmoothScroll'

const CAPS = [
  { title: 'Diving Survey & Underwater Cleaning', text: 'Underwater diving surveys and cleaning operations to support the inspection and maintenance of marine structures and vessel hulls.', photo: 'diver cleaning a ship hull underwater' },
  { title: 'Mooring Maintenance', text: 'Maintenance and support of marine mooring systems and associated infrastructure.', photo: 'dock workers handling mooring ropes at a bollard' },
  { title: 'Piling', text: 'Piling works supporting marine structures, waterfront developments and maritime infrastructure.', photo: 'marine piling rig working beside a quay' },
  { title: 'Yard Facilities', text: 'Marine yard facilities supporting vessel-related maintenance, repair and associated engineering activities.', photo: 'vessel in a dry dock with scaffolding' },
  { title: 'Demolition / Cutting / Blasting', text: 'Specialised marine and industrial demolition, cutting and blasting works for engineering and maintenance requirements.', photo: 'steel cutting beside a vessel in dry dock' },
  { title: 'Salvage – Anchors & Chain Removal', text: 'Marine salvage operations involving the recovery and removal of anchors and chains.', photo: 'diver handling anchor shackles underwater' },
]
const PRINCIPLES = [
  ['Technical Expertise', 'Applying engineering knowledge and technical capabilities to support specialised marine requirements.'],
  ['Precision & Reliability', 'Maintaining a professional approach to marine engineering and maintenance activities.'],
  ['Operational Understanding', 'Understanding the demands of marine environments and the importance of dependable engineering support.'],
]
const enquire = `/contact?service=${encodeURIComponent('Marine Engineering')}`

export default function MarineEngineering() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Marine Engineering', 'Underwater ship repair and maintenance, mooring maintenance, piling and maritime civil underwater engineering works from Harbor City Limited, Mombasa.')
  useReveal(root)
  return (
    <div ref={root}>
      <section className="pg pgi" style={{ backgroundImage: `linear-gradient(rgba(26,47,89,.78),rgba(26,47,89,.5) 45%,rgba(26,47,89,.92)),url(${drydockVessel})` }}>
        <p className="eyebrow" style={{ color: '#ff6b73' }}>Marine Engineering</p>
        <h1>Expertise Beneath the Surface. Solutions Above Expectations.</h1>
        <p>Marine environments demand specialised skills, technical expertise and precision.</p>
        <p style={{ marginTop: 14 }}>Harbor City Limited undertakes underwater ship repair and maintenance, mooring maintenance, piling and maritime civil underwater engineering works.</p>
        <p style={{ marginTop: 14 }}>Our marine engineering capabilities cover underwater inspection, cleaning, maintenance, marine construction and specialised underwater operations, supporting the requirements of demanding marine environments.</p>
        <div className="cta" style={{ marginTop: 34 }}>
          <Link className="btn fill" to={enquire}>Enquire about Marine Engineering</Link>
          <button className="btn" onClick={() => scrollToEl(document.getElementById('capabilities'))}>Explore our capabilities</button>
        </div>
      </section>

      <section className="wrap" id="capabilities">
        <p className="eyebrow">Our marine engineering capabilities</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Specialised Expertise Across Marine Environments.</h2>
        <p className="lead" style={{ margin: '22px 0 72px' }} data-r>Our marine engineering capabilities cover underwater operations, vessel maintenance, maritime infrastructure and specialised marine engineering works.</p>
        {CAPS.map((c, i) => (
          <div key={c.title} className={`split ${i % 2 ? 'rev' : ''}`} style={{ marginBottom: 'clamp(48px,7vw,100px)' }}>
            <Photo label={c.photo} className="rv" />
            <div data-r><p className="eyebrow">Service 0{i + 1}</p>
              <h3 style={{ fontSize: 'clamp(24px,3vw,40px)', fontWeight: 300, marginBottom: 16 }}>{c.title}</h3>
              <p className="lead" style={{ margin: 0 }}>{c.text}</p></div>
          </div>))}
      </section>

      <section className="wrap alt">
        <p className="eyebrow">Our approach</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Engineering Precision in Every Marine Operation.</h2>
        <p className="lead" style={{ marginTop: 22 }} data-r>We recognise the technical demands of marine environments and the importance of precision, safety and dependable engineering practices.</p>
        <p className="lead" style={{ marginTop: 14 }} data-r>Our approach focuses on understanding project requirements and delivering appropriate marine engineering solutions across underwater operations, vessel maintenance and maritime infrastructure.</p>
        <div className="pr3">{PRINCIPLES.map(([t, p], i) => <div key={t} data-r><i>0{i + 1}</i><h3>{t}</h3><p>{p}</p></div>)}</div>
      </section>

      <CtaBand title="Have a Marine Engineering Project?" text="From underwater inspections to specialised marine engineering works, Harbor City Limited is ready to discuss your project requirements." button="Enquire about Marine Engineering" to={enquire} />
    </div>)
}
