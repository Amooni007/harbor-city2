import { useRef } from 'react'
import PageHead from '../components/PageHead'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

export default function Projects() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Projects', 'Harbor City Limited project portfolio.')
  useReveal(root)
  return (<div ref={root}>
    <PageHead eyebrow="Projects" title="Project portfolio." lead="A portfolio structure ready to be populated with verified project information." />
    <section className="wrap"><p className="note" style={{ marginBottom: 40, maxWidth: '70ch' }}>The company profile does not list individual projects, so none are shown. Each slot below is a template: image, title, client, location, year, scope.</p>
      <div className="grid3">{[1, 2, 3, 4, 5, 6].map(i => (
        <div className="card" key={i} data-r><Photo label={`Project ${i} image`} className="dash" /><h3>Project title to be added</h3><p>Client · Location · Year · Scope: to be verified by Harbor City</p></div>))}</div></section>
    <CtaBand /></div>)
}
