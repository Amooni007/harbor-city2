import { useRef } from 'react'
import { Link } from 'react-router-dom'
import PageHead from '../components/PageHead'
import CtaBand from '../components/CtaBand'
import { IndustryColumns, CapabilityGrid } from '../components/Blocks'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

export default function Industries() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Industries', 'Port and terminal operations, marine and offshore work, construction, electrical and mechanical engineering, and environmental solutions.')
  useReveal(root)
  return (<div ref={root}>
    <PageHead eyebrow="Industries" title="Industries and capabilities we serve." lead="Port and terminal operations, marine and offshore work, construction, electrical and mechanical engineering, and environmental solutions." />
    <section className="wrap"><IndustryColumns /><p style={{ marginTop: 48 }}><Link className="btn ink" to="/services">See related services</Link></p></section>
    <section className="wrap dark"><p className="eyebrow">Marine &amp; offshore</p><CapabilityGrid /></section><CtaBand /></div>)
}
