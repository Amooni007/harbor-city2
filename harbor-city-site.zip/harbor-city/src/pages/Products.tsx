import { useRef } from 'react'
import { Link } from 'react-router-dom'
import PageHead from '../components/PageHead'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { PRODUCTS } from '../data/content'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

export default function Products() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Products & Equipment', 'Marine equipment and spares, pumps and motors, cables, switchgears, switchboards, distribution boards and reefer sockets.')
  useReveal(root)
  return (<div ref={root}>
    <PageHead eyebrow="Products & equipment" title="Equipment supplied to port, marine and industrial customers." lead="Catalogue categories from the company profile. Prices, specifications and stock availability are provided on enquiry." />
    <section className="wrap"><div className="grid3">{PRODUCTS.map(p => (
      <div className="card" key={p} data-r><Photo label={p} /><h3>{p}</h3><p>Ask our team about brands, specifications and availability.</p>
        <Link className="btn ink" to={`/contact?service=${encodeURIComponent('Products & Equipment')}&topic=${encodeURIComponent(p)}`}>Enquire</Link></div>))}</div></section>
    <CtaBand /></div>)
}
