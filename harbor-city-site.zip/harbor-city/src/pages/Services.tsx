import { useRef } from 'react'
import PageHead from '../components/PageHead'
import CtaBand from '../components/CtaBand'
import { ServiceRows } from '../components/Blocks'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

export default function Services() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Our services', 'Port services, marine engineering, supplies, construction, environmental solutions and offshore support from Harbor City Limited.')
  useReveal(root)
  return (<div ref={root}>
    <PageHead eyebrow="Our services" title="Six service areas, delivered by one team." lead="Marine engineering, supplies, construction, environmental solutions and offshore support, in line with the company profile." />
    <section className="wrap"><ServiceRows /></section><CtaBand /></div>)
}
