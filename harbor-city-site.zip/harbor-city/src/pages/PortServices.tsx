import { useRef } from 'react'
import { Link } from 'react-router-dom'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { terminal } from '../data/media'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'
import { scrollToEl } from '../hooks/useSmoothScroll'

const CAPS = [
  { title: 'Cable Solutions & Cable Reels', text: 'Cable management and cable reel solutions for industrial and port applications, supporting reliable power and cable distribution requirements.', photo: 'industrial cable reels at a container port' },
  { title: 'Reefer Automation', text: 'Electrical and automation solutions supporting refrigerated container operations and the infrastructure required for reefer container connectivity.', photo: 'technician inspecting a reefer container' },
  { title: 'Drive & Automation Technology', text: 'Drive systems and automation technology for industrial and terminal applications, supporting modern equipment and operational systems.', photo: 'variable-speed drive and control cabinet' },
]
const PRINCIPLES = [
  ['Technical Expertise', 'Applying engineering knowledge and technical capabilities to support complex operational requirements.'],
  ['Reliability', 'Prioritising dependable solutions and professional service delivery.'],
  ['Operational Support', 'Understanding the demands of port environments and the importance of keeping critical systems functioning.'],
]
const enquire = `/contact?service=${encodeURIComponent('Port Services')}`

export default function PortServices() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Port Services', 'Electrical, automation and technical solutions for port and terminal operations: cable reels, reefer automation, drive and automation technology.')
  useReveal(root)
  return (
    <div ref={root}>
      <section className="pg pgi" style={{ backgroundImage: `linear-gradient(rgba(26,47,89,.78),rgba(26,47,89,.5) 45%,rgba(26,47,89,.92)),url(${terminal})` }}>
        <p className="eyebrow" style={{ color: '#ff6b73' }}>Port Services</p>
        <h1>Powering the Infrastructure Behind Global Trade.</h1>
        <p>Ports are the backbone of international commerce, where precision, reliability and operational efficiency matter.</p>
        <p style={{ marginTop: 14 }}>Harbor City Limited provides specialised electrical, automation and technical solutions designed to support modern port and terminal environments.</p>
        <p style={{ marginTop: 14 }}>Through our engineering expertise and technology-driven approach, we help support the infrastructure, equipment and systems that keep port operations connected and moving.</p>
        <div className="cta" style={{ marginTop: 34 }}>
          <Link className="btn fill" to={enquire}>Enquire about Port Services</Link>
          <button className="btn" onClick={() => scrollToEl(document.getElementById('capabilities'))}>Explore our capabilities</button>
        </div>
      </section>

      <section className="wrap" id="capabilities">
        <p className="eyebrow">Our port service capabilities</p>
        <h2 style={{ maxWidth: '20ch' }} data-r>Specialised Solutions for Modern Port Operations</h2>
        <p className="lead" style={{ margin: '22px 0 72px' }} data-r>Our port service capabilities focus on electrical infrastructure, automation technology and specialised equipment solutions that support the operational demands of port and terminal environments.</p>
        {CAPS.map((c, i) => (
          <div key={c.title} className={`split ${i % 2 ? 'rev' : ''}`} style={{ marginBottom: 'clamp(48px,7vw,100px)' }}>
            <Photo label={c.photo} className="rv" />
            <div data-r><p className="eyebrow">Service 0{i + 1}</p>
              <h3 style={{ fontSize: 'clamp(24px,3vw,40px)', fontWeight: 300, marginBottom: 16 }}>{c.title}</h3>
              <p className="lead" style={{ margin: 0 }}>{c.text}</p></div>
          </div>))}
      </section>

      <section className="wrap alt">
        <p className="eyebrow">Our approach</p>
        <h2 style={{ maxWidth: '20ch' }} data-r>Engineering Solutions That Keep Operations Moving.</h2>
        <p className="lead" style={{ marginTop: 22 }} data-r>We recognise the importance of dependable infrastructure in modern port environments. Our approach combines technical knowledge, engineering expertise and a commitment to quality in supporting the systems and equipment used across industrial and marine operations.</p>
        <div className="pr3">{PRINCIPLES.map(([t, p], i) => <div key={t} data-r><i>0{i + 1}</i><h3>{t}</h3><p>{p}</p></div>)}</div>
      </section>

      <CtaBand title="Let’s Support Your Next Port Project." text="Looking for dependable electrical, automation or technical solutions for your port operations? Get in touch with Harbor City Limited to discuss your requirements." button="Enquire now" to={enquire} />
    </div>)
}
