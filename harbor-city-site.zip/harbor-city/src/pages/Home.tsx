import { useRef } from 'react'
import { Link } from 'react-router-dom'
import HeroSlideshow from '../components/HeroSlideshow'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { ServiceRows, IndustryColumns, CapabilityGrid, HseSection } from '../components/Blocks'
import { CLIENTS, PARTNERS, WHY } from '../data/content'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

const STEPS = [
  ['Customer places order', 'By phone call, email, or directly through the website, with product specifications and quantity.'],
  ['Order to warehouse', 'Once placed and verified, the warehouse is notified to pick, place and prepare for delivery.'],
  ['Packaging instructions', 'Pallets or full drums, depending on type of goods, mode of transportation and quantity.'],
  ['Delivery', 'In-stock items are shipped out and delivered within 24–48 hours of receiving the order.'],
]

export default function Home() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Marine, Civil, Electrical & Mechanical Engineering, Mombasa', 'Harbor City Limited, founded 2014 in Mombasa: marine and civil engineering contractor with electrical, mechanical engineering and supplies capabilities.')
  useReveal(root)
  return (
    <div ref={root}>
      <HeroSlideshow />

      <section className="wrap"><div className="split"><Photo label="Mombasa port and marine operations" />
        <div data-r><p className="eyebrow">Introducing Harbor City · Est. 2014</p><h2>You dream it, we build it.</h2>
          <p className="lead" style={{ margin: '24px 0 32px' }}>Harbor City Limited is a multi-disciplined marine and civil engineering contractor with a reputation for high standards of service to the marine industry. Mombasa Port is the gateway to East Africa and continental trade, and the company has diversified into marine civil engineering, supplies management, assembly and kitting.</p>
          <Link className="btn ink" to="/about">Read more</Link></div></div></section>

      <section className="wrap alt"><p className="eyebrow">Our core services</p><h2 style={{ maxWidth: '18ch', marginBottom: 64 }} data-r>Six disciplines, one accountable contractor.</h2><ServiceRows home /></section>

      <section className="wrap dark"><p className="eyebrow">Why choose Harbor City</p><h2 data-r>Five reasons customers return.</h2>
        <div className="why">{WHY.map((w, i) => <div key={w} data-r><i>0{i + 1}</i>{w}</div>)}</div></section>

      <section className="wrap"><p className="eyebrow">Industries we serve</p><h2 data-r>Real capabilities, organised by sector.</h2><IndustryColumns /></section>

      <section className="wrap dark"><p className="eyebrow">Marine &amp; offshore</p><h2 style={{ maxWidth: '20ch' }} data-r>Beneath the surface and offshore.</h2><CapabilityGrid /></section>

      <section className="wrap"><p className="eyebrow">Our workflow</p><h2 data-r>From order to delivery in four steps.</h2>
        <div className="flow">{STEPS.map(([t, p], i) => <div key={t} data-r><b>0{i + 1}</b><h3>{t}</h3><p>{p}</p>{i === 3 && <small>Applies to in-stock items only.</small>}</div>)}</div></section>

      <section className="wrap alt"><p className="eyebrow">Clients &amp; partners</p><h2 data-r>Trusted across ports, counties and industry.</h2>
        <h3 style={{ marginTop: 48 }}>Clients include</h3><div className="names">{CLIENTS.map(c => <span key={c} data-r>{c}</span>)}</div>
        <h3 style={{ marginTop: 56 }}>Partners</h3><div className="names">{PARTNERS.map(c => <span key={c} data-r>{c}</span>)}</div>
        <p className="note" style={{ marginTop: 28 }}>Listed as wordmarks. Official logos to be added once supplied or licensed by each organisation.</p></section>

      <section className="wrap"><div className="split rev"><Photo label="equipment and operator support" />
        <div data-r><p className="eyebrow">After-sales support</p><h2>Support that keeps equipment and operators productive.</h2>
          <p className="lead" style={{ marginTop: 22 }}>After-sales support is vital to ensure maximum use of both the equipment and the operator, so your investment translates into productivity, efficiency and profitability. Harbor City has developed a national and international network to provide long-term support and expertise on a local basis.</p></div></div></section>

      <section className="wrap alt"><HseSection /></section>
      <CtaBand />
    </div>
  )
}
