import { useRef } from 'react'
import { Link } from 'react-router-dom'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { constructionFrame } from '../data/media'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'
import { scrollToEl } from '../hooks/useSmoothScroll'

const CAPS = [
  { title: 'Mechanical & Electrical Identification', text: 'Mechanical and electrical identification solutions supporting the organisation and identification of equipment, systems and associated installations.', photo: 'cable tray installation in an industrial workshop' },
  { title: 'Cable Termination and Marking', text: 'Cable termination and marking works supporting electrical installation, identification and organised cable management requirements.', photo: 'electricians working on cable trays and distribution panels' },
  { title: 'Cabro and Paving Construction', text: 'Cabro and paving construction works supporting building, civil and external infrastructure requirements.', photo: 'interlocking cabro paving being compacted' },
  { title: 'Fabrication Department', text: 'Fabrication works supporting structural, industrial and engineering requirements.', photo: 'welders working on structural steel in a fabrication workshop' },
]
const PRINCIPLES = [
  ['Technical Capability', 'Applying practical engineering knowledge and technical skills across construction and industrial requirements.'],
  ['Quality & Precision', 'Maintaining attention to detail and professional standards throughout construction and fabrication activities.'],
  ['Project Understanding', 'Understanding client requirements and supporting projects with appropriate construction and engineering solutions.'],
]
const enquire = `/contact?service=${encodeURIComponent('Construction')}`

export default function Construction() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Construction', 'General building and civil construction with electrical, mechanical and fabrication works from Harbor City Limited, Mombasa.')
  useReveal(root)
  return (
    <div ref={root}>
      <section className="pg pgi" style={{ backgroundImage: `linear-gradient(rgba(26,47,89,.78),rgba(26,47,89,.5) 45%,rgba(26,47,89,.92)),url(${constructionFrame})` }}>
        <p className="eyebrow" style={{ color: '#ff6b73' }}>Construction</p>
        <h1>Building with Purpose. Engineering with Precision.</h1>
        <p>Harbor City Limited undertakes general building and civil construction alongside specialised electrical, mechanical and fabrication works.</p>
        <p style={{ marginTop: 14 }}>We bring together practical engineering capabilities to support diverse construction and industrial project requirements.</p>
        <div className="cta" style={{ marginTop: 34 }}>
          <Link className="btn fill" to={enquire}>Enquire about Construction</Link>
          <button className="btn" onClick={() => scrollToEl(document.getElementById('capabilities'))}>Explore our capabilities</button>
        </div>
      </section>

      <section className="wrap" id="capabilities">
        <p className="eyebrow">Our construction capabilities</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Integrated Construction &amp; Engineering Solutions.</h2>
        <p className="lead" style={{ margin: '22px 0 72px' }} data-r>Our construction capabilities cover general building and civil works alongside specialised mechanical, electrical and fabrication activities.</p>
        {CAPS.map((c, i) => (
          <div key={c.title} className={`split ${i % 2 ? 'rev' : ''}`} style={{ marginBottom: 'clamp(48px,7vw,100px)' }}>
            <Photo label={c.photo} className="rv" />
            <div data-r><p className="eyebrow">Service 0{i + 1}</p>
              <h3 style={{ fontSize: 'clamp(24px,3vw,40px)', fontWeight: 300, marginBottom: 16 }}>{c.title}</h3>
              <p className="lead" style={{ margin: 0 }}>{c.text}</p></div>
          </div>))}
      </section>

      <section className="wrap alt">
        <p className="eyebrow">Our approach</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Practical Engineering. Dependable Construction.</h2>
        <p className="lead" style={{ marginTop: 22 }} data-r>We understand that successful construction and engineering projects require careful coordination, technical understanding and attention to detail.</p>
        <p className="lead" style={{ marginTop: 14 }} data-r>Our approach focuses on understanding project requirements and applying appropriate construction, mechanical, electrical and fabrication capabilities.</p>
        <div className="pr3">{PRINCIPLES.map(([t, p], i) => <div key={t} data-r><i>0{i + 1}</i><h3>{t}</h3><p>{p}</p></div>)}</div>
      </section>

      <CtaBand title="Let’s Build Something That Lasts." text="Planning a building, civil, mechanical, electrical or fabrication project? Get in touch with Harbor City Limited to discuss your requirements." button="Enquire about Construction" to={enquire} />
    </div>)
}
