import { useRef } from 'react'
import { Link } from 'react-router-dom'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { cableReels } from '../data/media'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'
import { scrollToEl } from '../hooks/useSmoothScroll'

const CATEGORIES = [
  { title: 'Port & Marine Equipment and Spares', text: 'Equipment and replacement components supporting marine, port and terminal operations.', photo: 'marine engine with spare parts laid out' },
  { title: 'Pumps and Motors', text: 'Industrial pumping equipment, electric motors and associated components for marine and industrial applications.', photo: 'industrial pump and motor assemblies' },
  { title: 'LV, MV & HV Cables', text: 'Low, medium and high-voltage electrical cables supporting power distribution and industrial infrastructure requirements.', photo: 'cable drums in a warehouse' },
  { title: 'Switchgears, Switchboards & Distribution Boards', text: 'Electrical switching and distribution equipment designed to support industrial power management and electrical infrastructure.', photo: 'electrical distribution panel with circuit breakers' },
  { title: 'Reefer Sockets', text: 'Electrical connection equipment supporting refrigerated container power requirements and port terminal applications.', photo: 'technician servicing a reefer container power socket' },
  { title: 'Electrical Components & Panels', text: 'Electrical components and panel solutions supporting industrial electrical systems and technical installations.', photo: 'circuit breakers, contactors and terminal blocks' },
  { title: 'Hydraulic Man Lift Trucks', text: 'Hydraulic lifting equipment, including fire-fighting configurations where specified.', photo: 'hydraulic aluminium man lift platform' },
]
const PRINCIPLES = [
  ['Product Knowledge', 'Understanding the technical and operational requirements behind equipment and component selection.'],
  ['Sourcing Capabilities', 'Supporting client requirements through equipment and component sourcing.'],
  ['Industry Focus', 'Serving the equipment and supply requirements of marine, port and industrial environments.'],
]
const enquire = `/contact?service=${encodeURIComponent('Supplies')}`

export default function Supplies() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('Supplies', 'Port and marine equipment and spares, pumps and motors, cables, switchgear, reefer sockets, electrical components and hydraulic man lift trucks from Harbor City Limited.')
  useReveal(root)
  return (
    <div ref={root}>
      <section className="pg pgi" style={{ backgroundImage: `linear-gradient(rgba(26,47,89,.78),rgba(26,47,89,.5) 45%,rgba(26,47,89,.92)),url(${cableReels})` }}>
        <p className="eyebrow" style={{ color: '#ff6b73' }}>Supplies</p>
        <h1>The Right Equipment. The Right Solutions.</h1>
        <p>Harbor City Limited supports marine, port and industrial operations through the sourcing and supply of specialised equipment, electrical products and technical components.</p>
        <p style={{ marginTop: 14 }}>Our supply portfolio covers a range of equipment and products designed to support the operational and technical requirements of demanding industrial and maritime environments.</p>
        <div className="cta" style={{ marginTop: 34 }}>
          <Link className="btn fill" to={enquire}>Enquire about Supplies</Link>
          <button className="btn" onClick={() => scrollToEl(document.getElementById('categories'))}>Explore our products</button>
        </div>
      </section>

      <section className="wrap" id="categories">
        <p className="eyebrow">Our supply categories</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Equipment &amp; Solutions for Demanding Operations.</h2>
        <p className="lead" style={{ margin: '22px 0 72px' }} data-r>Our supply capabilities cover a range of marine, port and industrial equipment, electrical products and specialised technical components.</p>
        {CATEGORIES.map((c, i) => (
          <div key={c.title} className={`split ${i % 2 ? 'rev' : ''}`} style={{ marginBottom: 'clamp(48px,7vw,100px)' }}>
            <Photo label={c.photo} className="rv" />
            <div data-r><p className="eyebrow">Category 0{i + 1}</p>
              <h3 style={{ fontSize: 'clamp(24px,3vw,40px)', fontWeight: 300, marginBottom: 16 }}>{c.title}</h3>
              <p className="lead" style={{ margin: 0 }}>{c.text}</p></div>
          </div>))}
      </section>

      <section className="wrap alt">
        <p className="eyebrow">Why work with Harbor City</p>
        <h2 style={{ maxWidth: '22ch' }} data-r>Supporting Industry Through Reliable Supply Solutions.</h2>
        <p className="lead" style={{ marginTop: 22 }} data-r>We understand that dependable equipment and technical components play an important role in maintaining industrial and marine operations.</p>
        <p className="lead" style={{ marginTop: 14 }} data-r>Our approach focuses on understanding client requirements and sourcing appropriate equipment and supplies to support their operational needs.</p>
        <div className="pr3">{PRINCIPLES.map(([t, p], i) => <div key={t} data-r><i>0{i + 1}</i><h3>{t}</h3><p>{p}</p></div>)}</div>
      </section>

      <CtaBand title="Looking for the Right Equipment for Your Operations?" text="Whether you require marine equipment, electrical components, industrial products or specialised technical supplies, get in touch with Harbor City Limited to discuss your requirements." button="Request a supply enquiry" to={enquire} />
    </div>)
}
