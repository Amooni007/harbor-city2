import { useRef } from 'react'
import PageHead from '../components/PageHead'
import Photo from '../components/Photo'
import CtaBand from '../components/CtaBand'
import { Tags, HseSection } from '../components/Blocks'
import { VALUES, WHY } from '../data/content'
import { usePageMeta } from '../hooks/usePageMeta'
import { useReveal } from '../hooks/useReveal'

export default function About() {
  const root = useRef<HTMLDivElement>(null)
  usePageMeta('About us', 'Harbor City Limited was founded in 2014 and is a multi-disciplined marine and civil engineering contractor in Mombasa, Kenya.')
  useReveal(root)
  return (
    <div ref={root}>
      <PageHead eyebrow="About us" title="A marine and civil engineering contractor, founded 2014." lead="Multi-disciplined, rooted in Mombasa, and expanding where it is needed most." />
      <section className="wrap"><div className="split"><Photo label="Mombasa coast" />
        <div data-r><p className="eyebrow">Who we are</p>
          <p className="lead">Harbor City Limited was founded in 2014 and has quickly gained a reputation for the high standard of service provided to the marine industry. The company has expanded and diversified in marine civil engineering, gaining experience across a variety of marine-based operations.</p>
          <p className="lead">Mombasa Port, on Kenya’s coast, is strategically placed as the gateway to East Africa and continental trade. Harbor City researched customer needs and built solutions including supplies management, assembly and kitting.</p>
          <p className="lead">The company carries out underwater ship repair and maintenance, mooring maintenance, piling, maritime civil underwater engineering works and equipment supplies, with an ongoing commitment to a very high standard of service.</p></div></div></section>
      <section className="wrap dark"><p className="eyebrow">Achieved through</p><h2 data-r>Standards, partners, people.</h2>
        <Tags items={['Compliance with international standards and regulations', 'Strategic partners', 'Strong team', 'Growing market demand', 'Competitive price regimes']} />
        <h3 style={{ marginTop: 64 }}>Core values</h3><Tags items={VALUES} />
        <p style={{ maxWidth: '60ch', color: '#b9c9dc', marginTop: 28 }}>Honesty is the strength upon which the Harbor City name stands, and complying is adamant whether publicly or privately.</p></section>
      <section className="wrap"><p className="eyebrow">Why choose us</p><Tags items={WHY} /></section>
      <section className="wrap alt"><HseSection /></section>
      <CtaBand />
    </div>)
}
