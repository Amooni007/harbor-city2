# Harbor City Limited website

Vite + React 18 + TypeScript + React Router 6 + GSAP + Lenis.

    npm install
    npm run dev        # http://localhost:5173
    npm run build      # outputs dist/

## Structure
- `src/pages/` Home, About, Services, Industries, Products, Projects, Contact (one file each)
- `src/components/` Navbar, Footer, PageLoader + PageTransition (tower), VideoBackground, ScrollToTop, Photo, PageHead, CtaBand, Blocks
- `src/data/content.ts` all company text lists (from the company profile PDF); `src/data/media.ts` maps media to sections
- `src/assets/` `videos/hero.mp4`, `images/` (hero poster + 4 photos), `logos/` (logo + tower)
- `src/styles/` global.css, animations.css, responsive.css

## Replacing media
Overwrite the files in `src/assets/` keeping the same names, or edit `src/data/media.ts`.
`hero.mp4` is a 1920px, 3 MB re-encode of the supplied 4K clip; images are 1600px WebP.
Photos not yet supplied show a labelled "photo slot" (see `PHOTOS` in `media.ts`).

## Deployment
Uses BrowserRouter, so the host needs an SPA fallback. `public/_redirects` covers Cloudflare Pages and Netlify.

## Still to do
- Contact form opens the visitor's email app (mailto). Connect Formspree/EmailJS/an API in `pages/Contact.tsx`.
- Add verified projects (Projects page), official client/partner logos, and a map once the location is verified.
- Add sitemap.xml once the final domain is known.
- The tower loader is a raster crop from the supplied logo; replace `assets/logos/tower.png` with an SVG if the vector logo file is available.
